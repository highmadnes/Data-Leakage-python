def main_context(request):
	if request.user.is_authenticated:
		if request.user.user_type == 'agency':
			base_template = 'agency_base.html'
		elif request.user.is_superuser:
			base_template = 'admin_base.html'
		elif request.user.user_type == 'plant':
			base_template = 'plant_base.html'
		else:
			base_template = 'user_base.html'
	else:
		base_template = 'base.html'

	context ={
		'app_title':'CWDS',
		'base_template':base_template
	}
	return context