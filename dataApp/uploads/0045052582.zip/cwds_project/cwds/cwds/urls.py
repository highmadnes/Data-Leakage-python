from django.conf.urls import url,include
from django.contrib import admin
from django.conf import settings
from django.views.static import serve
from django.contrib.auth import views as auth_views
from django.conf.urls import (
handler400, handler403, handler404, handler500
)


urlpatterns = [
    url(r'^login/$', auth_views.LoginView.as_view(template_name='registration/login.html',
        extra_context={
        	'title':'Admin',
        	'next': '/admin-dashboard',
        }), name='login'),
    url(r'^agency-login/$', auth_views.LoginView.as_view(template_name='registration/staff_login.html',
        extra_context={
        	'title':'Agency Login',
        	'next': '/agency-dashboard',
        	'join_us':'/create-agency',
            'login_url':'agency_login'
        }), name='agency_login'),
    url(r'^plant-login/$', auth_views.LoginView.as_view(template_name='registration/staff_login.html',
        extra_context={
        	'title':'Plant Login',
        	'next': '/plant-dashboard',
        	'join_us':'/create-plant',
            'login_url':'plant_login'
        }), name='plant_login'),
    url(r'^user-login/$', auth_views.LoginView.as_view(template_name='registration/staff_login.html',
        extra_context={
        	'title':'User Login',
        	'next': '/user-dashboard',
        	'join_us':'/create-user',
            'login_url': 'user_login'
        }), name='user_login'),
    url(r'^', include('django.contrib.auth.urls')),
    url(r'^', include('myuser.urls',namespace='myuser')),
    url(r'^', include('general.urls',namespace='general')),

    url(r'^static/(?P<path>.*)$', serve, { 'document_root': settings.STATIC_FILE_ROOT,}),
    url(r'^media/(?P<path>.*)$', serve, { 'document_root': settings.MEDIA_ROOT,}),
]

handler400 = "cwds.views.handler400"
handler403 = "cwds.views.handler403"
handler404 = "cwds.views.handler404"
handler500 = "cwds.views.handler500"